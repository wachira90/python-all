# Example 1

This example uses the raw temp_data.csv file 
to get data into the program and run
various Python functions on it.

In particular getting the average temperature
for a date across all the samples, and getting the
average temperature for every week for the entire
year and returning it sorted.