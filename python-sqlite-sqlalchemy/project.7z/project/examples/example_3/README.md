# Example 3

This example uses SqlAlchemy to access the temp_data.db 
database to get data into the program and run
various SqlAlchemy object methods to get the data.

In particular getting the average temperature
for a date across all the samples, and getting a list 
of all the average temps for the year in sorted order.