# Example 2

This example uses temp_data.db database
file to get data into the program and run
various functions on it that use Sqlite SQL 
to access the data.

In particular getting the average temperature
for a date across all the samples, and getting the
average temperature for every week for the entire
year and returning it sorted.